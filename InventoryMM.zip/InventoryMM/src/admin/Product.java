package admin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Product {
    private String name;
    private double price;
    private int quantity;
    private IntegerProperty availableStock;
	private String image;

    // Constructor ใหม่ (รองรับ quantity ที่ส่งเข้ามา)
    public Product(String name, int quantity, double price, String imagePath, int availableStock) {
        this.name = name;
        this.quantity = quantity; // ค่าเริ่มต้นหรือค่าที่ส่งมาจาก addToCart
        this.price = price;
        this.image = imagePath;
        this.availableStock = new SimpleIntegerProperty(availableStock);
    }

    // Constructor เดิม (ถ้ามี)
    public Product(String name, int stock, double price, String imagePath) {
        this.name = name;
        this.quantity = 0; // ค่าเริ่มต้นสำหรับสินค้าใหม่
        this.price = price;
        this.image = imagePath;
        this.availableStock = new SimpleIntegerProperty(stock);
    }

    public static ImageView loadImageFromDatabase(int id) {
        ImageView imageView = new ImageView();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // เชื่อมต่อฐานข้อมูล
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory", "manaji", "zoomgik2341");
            
            String query = "SELECT image FROM products WHERE id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                byte[] imageData = rs.getBytes("image");
                String tempImagePath = saveImageToTempFile(imageData);

                if (tempImagePath != null) {
                    Image image = new Image("file:" + tempImagePath);
                    imageView.setImage(image);
                    imageView.setFitWidth(100);
                    imageView.setFitHeight(100);
                    imageView.setPreserveRatio(true);
                } else {
                    System.err.println("Failed to save image to temporary file.");
                }
            } else {
                System.err.println("No image found for the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("SQL error occurred: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error occurred: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
        return imageView;
    }

    static String saveImageToTempFile(byte[] imageBytes) {
        if (imageBytes == null || imageBytes.length == 0) {
            System.err.println("Invalid image data.");
            return null;
        }
        try {
            File tempFile = File.createTempFile("product_image_", ".png");
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(imageBytes);
            }
            System.out.println("Temporary file created: " + tempFile.getAbsolutePath());
            return tempFile.getAbsolutePath();
        } catch (IOException e) {
            System.err.println("Error saving image to temporary file: " + e.getMessage());
            return null;
        }
    }
    
    
    private byte[] imageBytes; // ฟิลด์สำหรับเก็บข้อมูลไบต์ของรูปภาพ

    public Product(String name, int quantity, double price, String imagePath, int availableStock, byte[] imageBytes) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.image = imagePath;
        this.availableStock = new SimpleIntegerProperty(availableStock);
        this.imageBytes = imageBytes;
    }

    // Getter สำหรับ imageBytes
    public byte[] getImageBytes() {
        return this.imageBytes;
    }

    // Setter สำหรับ imageBytes (หากต้องการอัปเดตค่า)
    public void setImageBytes(byte[] imageBytes) {
        this.imageBytes = imageBytes;
    }
    

    // Getter และ Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price; // ราคาต่อหน่วย
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String imagePath) {
        this.image = imagePath;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getAvailableStock() {
        return availableStock.get();
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock.set(availableStock);
    }

    public IntegerProperty availableStockProperty() {
        return availableStock;
    }

    public double getCalculatedPrice() {
        return price * quantity; // ราคาคำนวณตามจำนวนสินค้า
    }

    public void reduceStock(int amount) {
        if (amount > 0 && amount <= getAvailableStock()) {
            this.availableStock.set(this.availableStock.get() - amount);
        } else {
            throw new IllegalArgumentException("Invalid amount to reduce stock.");
        }
    }

    public void increaseStock(int amount) {
        if (amount > 0) {
            this.availableStock.set(this.availableStock.get() + amount);
        } else {
            throw new IllegalArgumentException("Invalid amount to increase stock.");
        }
    }

    // เพิ่ม Method สำหรับ Debugging
    @Override
    public String toString() {
        return "Product{name='" + name + "', price=" + price + ", quantity=" + quantity +
                ", availableStock=" + getAvailableStock() + "}";
    }


}
