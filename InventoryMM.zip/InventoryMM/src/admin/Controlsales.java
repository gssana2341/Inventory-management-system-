package admin;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Controlsales {

    @FXML
    private Button Inventory_bt, dashbord_bt, reports_bt, addButton, menu_ReceiptBtn, dashbord_bt1, dashbord_bt2,
            menu_PayBtn, menu_RemoveBtn;

    @FXML
    private ImageView Logout;

    @FXML
    private AnchorPane background;

    @FXML
    private TableView<Product> cartTableView;

    @FXML
    private TableColumn<Product, String> productNameColumn;

    @FXML
    private TableColumn<Product, Integer> quantityColumn;

    @FXML
    private TableColumn<Product, Double> priceColumn, productPriceColumn;

    @FXML
    private TableColumn<Product, Void> editColumn;

    @FXML
    private GridPane productGrid;

    @FXML
    private TextField menu_Amount;

    @FXML
    private Text menu_Total, menu_Change;

    private ObservableList<Product> productList = FXCollections.observableArrayList();
    private ObservableList<Product> cartList = FXCollections.observableArrayList();

    private String image;

    @FXML
    void printReceipt(ActionEvent event) {
        // Implement print receipt functionality
    }

    @FXML
    private void handlePayment(ActionEvent event) {
        try {
            double total = Double.parseDouble(menu_Total.getText());
            double amount = Double.parseDouble(menu_Amount.getText());
            double change = amount - total;

            FXMLLoader loader = new FXMLLoader(getClass().getResource("Receipt.fxml"));
            Parent root = loader.load();

            ReceiptController controller = loader.getController();
            ObservableList<ReceiptController.ReportRow> reportData = FXCollections.observableArrayList();

            for (Product product : cartList) {
                double amountPerItem = product.getPrice() * product.getQuantity();
                reportData.add(new ReceiptController.ReportRow("13/01/2025", product.getName(), "Customer 1",
                        product.getQuantity(), product.getPrice(), amountPerItem));
            }

            controller.setReportData(reportData);
            controller.setDateRange("2025-01-15", "2025-01-15");

            Stage stage = new Stage();
            stage.setTitle("Receipt");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onRemoveButtonClicked() {
        Product selectedProduct = cartTableView.getSelectionModel().getSelectedItem();

        if (selectedProduct != null) {
            System.out.println("Removing product: " + selectedProduct.getName());

            // คืนสต็อกในฐานข้อมูล
            for (Product product : productList) {
                if (product.getName().equals(selectedProduct.getName())) {
                    int updatedStock = product.getAvailableStock() + selectedProduct.getQuantity();
                    product.setAvailableStock(updatedStock);

                    // อัปเดตฐานข้อมูล
                    if (updateProductStockInDatabase(product.getName(), updatedStock)) {
                        System.out.println("Stock updated in database.");
                    } else {
                        showErrorDialog("Failed to update stock in database.");
                    }
                    break;
                }
            }

            // ลบข้อมูลในตาราง
            cartList.remove(selectedProduct);
            cartTableView.refresh();
            updateTotal();
        } else {
            showErrorDialog("No product selected for removal.");
        }
    }

    @FXML
    private void initialize() {
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("calculatedPrice"));

        cartTableView.setItems(cartList);
        fetchProductsFromDatabase();
        populateGrid();
        addEditButtonToTable();

        menu_Amount.textProperty().addListener((observable, oldValue, newValue) -> calculateChange(newValue));
    }

    private void addEditButtonToTable() {
        editColumn.setCellFactory(param -> new TableCell<Product, Void>() {
            private final Button editButton = new Button("Edit");

            {
                editButton.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    openEditDialog(product);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(editButton);
                }
            }
        });
    }

    private void openEditDialog(Product product) {
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Edit Product");

        // เก็บค่าเดิมไว้
        final int originalQuantity = product.getQuantity();
        final int originalStock = product.getAvailableStock();

        VBox vbox = new VBox(15);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);

        Label titleLabel = new Label("Edit Product");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Label nameLabel = new Label(product.getName());
        nameLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        Label priceLabel = new Label(String.format("฿%.2f", product.getPrice()));
        priceLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        TextField quantityField = new TextField(String.valueOf(product.getQuantity()));
        quantityField.setPromptText("Enter new quantity");

        Button saveButton = new Button("Save");
        saveButton.setOnAction(e -> {
            try {
                int newQuantity = Integer.parseInt(quantityField.getText()); // จำนวนใหม่ที่กรอก
                int quantityDifference = newQuantity - originalQuantity;   // ความแตกต่างของจำนวน
                int newStock = originalStock - quantityDifference;         // สต็อกใหม่

                if (newQuantity >= 0 && newStock >= 0) {
                    // อัปเดตสินค้าใน cartList
                    for (Product cartProduct : cartList) {
                        if (cartProduct.getName().equals(product.getName())) {
                            cartProduct.setQuantity(newQuantity); // เปลี่ยนจำนวนใน Cart
                            cartProduct.setAvailableStock(newStock); // อัปเดตจำนวนคงเหลือใน Cart
                            break;
                        }
                    }
                    // อัปเดตสินค้าใน productList
                    for (Product gridProduct : productList) {
                        if (gridProduct.getName().equals(product.getName())) {
                            gridProduct.setAvailableStock(newStock); // ลดจำนวนสินค้าใน Stock
                            break;
                        }
                    }
                    // รีเฟรช UI
                    cartTableView.refresh();  // รีเฟรชตาราง
                    populateGrid();           // รีเฟรช GridView
                    dialogStage.close();      // ปิดหน้าต่างแก้ไข
                } else {
                    // คืนค่ากลับไปเหมือนเดิม (ข้อมูลเดิม)
                    revertChanges(product, newStock, newStock);
                    showErrorDialog("Invalid quantity. Ensure it does not exceed available stock.");
                }
            } catch (NumberFormatException ex) {
                revertChanges(product, originalStock, originalStock);
                showErrorDialog("Invalid input. Please enter a valid number.");
            } catch (Exception ex) {
                revertChanges(product, originalStock, originalStock);
                showErrorDialog("Unexpected error: " + ex.getMessage());
            }
        });
        
       
        Button cancelButton = new Button("Cancel");
        cancelButton.setOnAction(e -> dialogStage.close());

        HBox buttonBox = new HBox(10, saveButton, cancelButton);
        buttonBox.setAlignment(Pos.CENTER);

        vbox.getChildren().addAll(titleLabel, 
            new VBox(5, new Label("Name:"), nameLabel),
            new VBox(5, new Label("Price:"), priceLabel),
            new VBox(5, new Label("Quantity:"), quantityField), 
            buttonBox);

        Scene scene = new Scene(vbox);
        dialogStage.setScene(scene);
        dialogStage.showAndWait();
    }
    
	private void revertChanges(Product product, int originalQuantity, int originalStock) {
		for (Product cartProduct : cartList) {
			if (cartProduct.getName().equals(product.getName())) {
				cartProduct.setQuantity(originalQuantity); // คืนค่าจำนวนเดิมใน Cart
				cartProduct.setAvailableStock(originalStock); // คืนค่าสต็อกเดิมใน Cart
				break;
			}
		}
		for (Product gridProduct : productList) {
			if (gridProduct.getName().equals(product.getName())) {
				gridProduct.setAvailableStock(originalStock); // คืนค่าสต็อกเดิมใน Stock
				break;
			}
		}
		cartTableView.refresh(); // รีเฟรช UI
		populateGrid();
	}
    
    private void showErrorDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean updateProductStockInDatabase(String productName, int newStock) {
        String query = "UPDATE products SET stock = ? WHERE name = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory", "manaji",
                "zoomgik2341"); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, newStock);
            pstmt.setString(2, productName);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void fetchProductsFromDatabase() {
        productList.clear();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory", "manaji", "zoomgik2341");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {

            while (rs.next()) {
                byte[] imageData = rs.getBytes("image");
                productList.add(new Product(
                    rs.getString("name"),
                    1,
                    rs.getDouble("price"),
                    null,
                    rs.getInt("stock"),
                    imageData
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateGrid() {
        productGrid.getChildren().clear();
        int column = 0, row = 0;

        for (Product product : productList) {
            VBox card = createCard(product);
            productGrid.add(card, column++, row);

            if (column == 5) {
                column = 0;
                row++;
            }
        }
    }

    private VBox createCard(Product product) {
        VBox card = new VBox();
        card.setStyle("-fx-border-color: lightgray; -fx-padding: 10; -fx-spacing: 5;");

        ImageView productImage = new ImageView();
        try {
            byte[] imageData = product.getImageBytes();
            if (imageData != null && imageData.length > 0) {
                String tempImagePath = Product.saveImageToTempFile(imageData);
                if (tempImagePath != null) {
                    Image image = new Image("file:" + tempImagePath);
                    productImage.setImage(image);
                    productImage.setFitWidth(100);
                    productImage.setFitHeight(100);
                    productImage.setPreserveRatio(true);
                } else {
                    throw new Exception("Failed to create temporary image file");
                }
            } else {
                throw new Exception("No image data available");
            }
        } catch (Exception e) {
            System.err.println("Error loading image for product: " + e.getMessage());
            productImage.setImage(new Image(getClass().getResourceAsStream("/path/to/default/image.png")));
            productImage.setFitWidth(100);
            productImage.setFitHeight(100);
        }

        Button addButton = new Button("Add");
        addButton.setStyle("-fx-background-color: green; -fx-text-fill: white;");
        addButton.setOnAction(e -> addToCart(product));

        Text availableText = new Text("Available: " + product.getAvailableStock());
        card.getChildren().addAll(productImage, new Text("Name: " + product.getName()), availableText, addButton);

        product.availableStockProperty().addListener((obs, oldVal, newVal) -> {
            availableText.setText("Available: " + newVal);
        });

        return card;
    }

    private void addToCart(Product product) {
        if (product.getAvailableStock() <= 0) {
            System.out.println("Out of stock!");
            return;
        }

        for (Product cartProduct : cartList) {
            if (cartProduct.getName().equals(product.getName())) {
                cartProduct.setQuantity(cartProduct.getQuantity()+1);
                product.reduceStock(1);
                updateTotal();
                cartTableView.refresh();
                return;
            }
        }

        cartList.add(new Product(product.getName(), 1, product.getPrice(), product.getImage(),
                product.getAvailableStock() - 1));
        product.reduceStock(1);
        updateTotal();
        cartTableView.refresh();
    }

	private void calculateChange(String amountText) {
		try {
			double total = Double.parseDouble(menu_Total.getText());
			double amount = Double.parseDouble(amountText);

			if (amount < total) {
				menu_Change.setText("Insufficient amount");
			} else {
				menu_Change.setText(String.format("%.2f", amount - total));
			}
		} catch (NumberFormatException e) {
			menu_Change.setText("Invalid amount");
		}
	}

	private void updateTotal() {
		double total = cartList.stream().mapToDouble(Product::getCalculatedPrice).sum();
		menu_Total.setText(String.format("%.2f", total));
	}

	@FXML
	private void onReceiptButtonClicked() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Receipt.fxml"));
			Parent root = loader.load();

			// รับ Controller ของ Receipt และตั้งค่าข้อมูล
			ReceiptController controller = loader.getController();

			// ส่งข้อมูล cartList ไปยัง ReceiptController
			ObservableList<ReceiptController.ReportRow> reportData = FXCollections.observableArrayList();
			for (Product product : cartList) {
				double amount = product.getPrice() * product.getQuantity();
				reportData.add(new ReceiptController.ReportRow(getCurrentDate(), // ใช้วันที่ปัจจุบัน
						product.getName(), "Customer 1", // สมมติชื่อลูกค้า
						product.getQuantity(), product.getPrice(), amount));
			}

			// ตั้งค่าวันที่ใน ReceiptController
			String currentDate = getCurrentDate(); // วันที่ปัจจุบัน
			controller.setDateRange(currentDate, currentDate); // ใช้วันที่เดียวกันสำหรับช่วงวันที่

			Stage stage = new Stage();
			stage.setTitle("Receipt");
			stage.setScene(new Scene(root));
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ฟังก์ชันสำหรับดึงวันที่ปัจจุบันในรูปแบบ "dd/MM/yyyy"
	private String getCurrentDate() {
		// สร้างรูปแบบวันที่
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		// ดึงวันที่ปัจจุบัน
		LocalDate currentDate = LocalDate.now();
		// แปลงวันที่ปัจจุบันเป็น String
		return currentDate.format(formatter);
	}

	@FXML
	void Logoutbutton(MouseEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Login/login.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void report_button(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/admin/reports.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void Inventory_button(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/admin/Inventory.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}

	@FXML
    private void dashboard_button(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/admin/main.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
    }
	
	@FXML
    private void Saler_button (ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/admin/saler.fxml"));
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow(); 
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    

}
