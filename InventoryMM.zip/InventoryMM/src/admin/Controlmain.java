
package admin;

import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import application.connectsql;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Controlmain {

	@FXML
	private TableColumn<ProductReport, String> viewType;

	@FXML
	private TableColumn<ProductReport, Integer> viewStock;

	@FXML
	private Button Inventory_bt;

	@FXML
	private LineChart<String, Number> Liinechart;
	
    @FXML
    private AreaChart<String, Number> Liinechart2;
    
	@FXML
	private CategoryAxis xAxis;
	
	@FXML
	private NumberAxis yAxis;

	@FXML
	private Label lowstocklable;

	@FXML
	private Label outstocklable;

	@FXML
	private Label avaliblelable;

	@FXML
	private Label totallable;

	@FXML
	private AnchorPane background;

	@FXML
	private Button dashbord_bt;

	@FXML
	private Button reports_bt;

	@FXML
	private PieChart statusview;

	@FXML
	private TableColumn<ProductReport, ImageView> viewImage;

	@FXML
	private TableColumn<ProductReport, String> viewaction;

	@FXML
	private TableView<ProductReport> viewtabledashboard;

	@FXML
	private TableColumn<ProductReport, String> viewtimiestamp;

	@FXML
	private void initialize() {
		loadDataFromDatabase();
		loadDataFromDatabase2();
		loadDataFromDatabase3();
		loadDataFromDatabase4();
		loadDataFromDatabase5();
	}

	private void loadDataFromDatabase() {
		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn
						.prepareStatement("SELECT status, COUNT(*) AS count FROM products GROUP BY status")) {

			ResultSet rs = stmt.executeQuery();
			int availableForSale = 0;
			int outOfStock = 0;
			int lowStock = 0;

			while (rs.next()) {
				String status = rs.getString("status");
				int count = rs.getInt("count");

				switch (status) {
				case "Available for Sale":
					availableForSale = count;
					break;
				case "Out of Stock":
					outOfStock = count;
					break;
				case "Low Stock":
					lowStock = count;
					break;
				}
			}

			// Update labels
			avaliblelable.setText(String.valueOf(availableForSale));
			outstocklable.setText(String.valueOf(outOfStock));
			lowstocklable.setText(String.valueOf(lowStock));
			totallable.setText(String.valueOf(availableForSale + outOfStock + lowStock));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadDataFromDatabase2() {
		List<ProductReport> productReports = new ArrayList<>();

		// SQL query to get records sorted by id in descending order
		String query = "SELECT r.action, r.timestamp " + "FROM report_table r " + "ORDER BY r.id DESC";

		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn.prepareStatement(query)) {

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				String action = rs.getString("action");
				String timestamp = rs.getString("timestamp");

				// Add data to ProductReport
				productReports.add(new ProductReport(action, timestamp));
			}

			// Bind data to TableView
			viewaction.setCellValueFactory(new PropertyValueFactory<>("action"));
			viewtimiestamp.setCellValueFactory(new PropertyValueFactory<>("timestamp"));

			// Set data in TableView
			viewtabledashboard.getItems().setAll(productReports);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadDataFromDatabase3() {
		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn
						.prepareStatement("SELECT status, COUNT(*) AS count FROM products GROUP BY status")) {

			ResultSet rs = stmt.executeQuery();
			int availableForSale = 0;
			int outOfStock = 0;
			int lowStock = 0;

			while (rs.next()) {
				String status = rs.getString("status");
				int count = rs.getInt("count");

				switch (status) {
				case "Available for Sale":
					availableForSale = count;
					break;
				case "Out of Stock":
					outOfStock = count;
					break;
				case "Low Stock":
					lowStock = count;
					break;
				}
			}

			// Update labels
			avaliblelable.setText(String.valueOf(availableForSale));
			outstocklable.setText(String.valueOf(outOfStock));
			lowstocklable.setText(String.valueOf(lowStock));
			totallable.setText(String.valueOf(availableForSale + outOfStock + lowStock));

			// Update PieChart
			statusview.getData().clear();
			statusview.getData().add(new PieChart.Data("Out of Stock", outOfStock));
			statusview.getData().add(new PieChart.Data("Low Stock", lowStock));
			statusview.getData().add(new PieChart.Data("Available for Sale", availableForSale));
						
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadDataFromDatabase4() {
	    List<XYChart.Data<String, Number>> dataPoints = new ArrayList<>();

	    String query = "SELECT type, stock FROM products ORDER BY id DESC";

	    try (Connection conn = new connectsql().getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        // ดึงข้อมูลจากฐานข้อมูลและสร้าง Data Points
	        while (rs.next()) {
	            String type = rs.getString("type");
	            int stock = rs.getInt("stock");

	            // เพิ่มข้อมูลใน List
	            dataPoints.add(new XYChart.Data<>(type, stock));
	        }

	        // สร้างชุดข้อมูล Series สำหรับกราฟ
	        XYChart.Series<String, Number> series = new XYChart.Series<>();
	        series.setName("Stock");

	        // เพิ่ม Data Points ลงใน Series
	        series.getData().addAll(dataPoints);

	        // เพิ่มข้อมูลชุดนี้ลงใน LineChart
	        Liinechart.getData().add(series);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	private void loadDataFromDatabase5() {
	    List<XYChart.Data<String, Number>> dataPoints = new ArrayList<>();

	    String query = "SELECT name, price FROM products ORDER BY id DESC";

	    try (Connection conn = new connectsql().getConnection();
	         PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        // Fetch data from the database and create Data Points
	        while (rs.next()) {
	            String name = rs.getString("name");
	            double price = rs.getDouble("price");

	            // Add data to the list
	            dataPoints.add(new XYChart.Data<>(name, price));
	        }

	        // Create a data series for the chart
	        XYChart.Series<String, Number> series = new XYChart.Series<>();
	        series.setName("Prices");

	        // Add data points to the series
	        series.getData().addAll(dataPoints);

	        // Add the series to the AreaChart
	        Liinechart2.getData().add(series);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static class ProductReport {
		private final String type;
		private final int stock;
		private final String action;
		private final String timestamp;

		public ProductReport(String type, int stock) {
			this.type = type;
			this.stock = stock;
			this.action = null;
			this.timestamp = null;
		}

		public ProductReport(String type, int stock, String action, String timestamp) {
			this.type = type;
			this.stock = stock;
			this.action = action;
			this.timestamp = timestamp;
		}

		public ProductReport(String action, String timestamp) {
			this(null, 0, action, timestamp);
		}

		public String getType() {
			return type;
		}

		public int getStock() {
			return stock;
		}

		public String getAction() {
			return action;
		}

		public String getTimestamp() {
			return timestamp;
		}
	}
	
	@FXML
    void Logoutbutton(MouseEvent event) throws IOException{
    	Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
	
	@FXML
	void Inventory_button(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/admin/Inventory.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void report_button(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/admin/reports.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setScene(scene);
		stage.show();
	}
	
	@FXML
    private void dashboard_button(ActionEvent event) throws IOException {
		
    }
	
	@FXML
	void Saler_button(ActionEvent event) throws IOException {
	    FXMLLoader loader = new FXMLLoader(getClass().getResource("/admin/saler.fxml"));
	    Parent root = loader.load();
	    Scene scene = new Scene(root);
	    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
	    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    stage.setScene(scene);
	    stage.show();
}

}
