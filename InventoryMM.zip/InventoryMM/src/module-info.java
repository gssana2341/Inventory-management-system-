
module InventoryMM {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	requires transitive javafx.graphics;
	requires javafx.swing;
	requires javafx.base;
	requires jakarta.mail;
	requires jakarta.activation;
	requires javafx.web;
	
	opens admin to javafx.fxml;
	opens Login to javafx.fxml;
	opens application to javafx.fxml;
	opens manager to javafx.fxml;
	
	exports admin;
	exports Login;
	exports application;
	exports manager;
}
