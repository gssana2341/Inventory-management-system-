
package application;

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class reports extends Application {

	@Override
	public void start(Stage primaryStage) {
		try {
			URL fxmlUrl = getClass().getResource("reports.fxml");
			if (fxmlUrl == null) {throw new RuntimeException("Cannot find reports.fxml");}
			Parent root = FXMLLoader.load(fxmlUrl);
			Scene scene = new Scene(root);
			URL cssUrl = getClass().getResource("reports.css");
			if (cssUrl != null) {scene.getStylesheets().add(cssUrl.toExternalForm());}
			primaryStage.setTitle("Inventory system");
			primaryStage.getIcons().add(new Image("file:C:/Users/zombiman/eclipse-workspace/InventoryMM/รูป/package.png"));																					// absolute path
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
