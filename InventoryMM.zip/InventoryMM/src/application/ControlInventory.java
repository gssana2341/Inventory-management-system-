package application;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import Login.UserSession;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.util.Callback;

public class ControlInventory {

	
	@FXML
    private TableView<ControlAddproduct> Product_Table;
    @FXML
    private TableColumn<ControlAddproduct, String> Codecal;  
    @FXML
    private TableColumn<ControlAddproduct, String> Picturecal;
    @FXML
    private TableColumn<ControlAddproduct, Double> Pricecal;
    @FXML
    private TableColumn<ControlAddproduct, String> Productcal;
    @FXML
    private TableColumn<ControlAddproduct, Integer> Soldcal;
    @FXML
    private TableColumn<ControlAddproduct, String> Statuscal;
    @FXML
    private TableColumn<ControlAddproduct, Integer> Stockcal;
    @FXML
    private TableColumn<ControlAddproduct, String> Typscal;
    @FXML
    private TableColumn<ControlAddproduct, Void> ActionColumn;
    @FXML
    private ImageView Logout;
    @FXML
    private Button Deletetabla;
    @FXML
    private Button refreshtabla;
    @FXML
    private TextField search;
    @FXML
    private MenuButton filterComboBox;
    @FXML
    private MenuButton SortOrderbutton;
    
    private String username;
    
    private ObservableList<ControlAddproduct> InventoryList = FXCollections.observableArrayList();

    private connectsql databaseConnector;
    private static Connection connection;

    @FXML
    private MenuButton filterMenuButton;
 // / ฟังก์ชันสำหรับปุ่มอัปโหลดไฟล์
    public void handleUploadFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File to Upload");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        // เปิด FileChooser
        Stage stage = new Stage(); // หรือใช้ stage ปัจจุบัน
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            String fileExtension = getFileExtension(file); // ตรวจสอบชนิดไฟล์

            if (fileExtension.equals("csv")) {
                // อ่านไฟล์ CSV
                readAndInsertToDatabase(file);
            } else {
                showAlert("Invalid File", "Please select a valid CSV file.", Alert.AlertType.ERROR);
            }
        }
    }
    // ฟังก์ชันสำหรับดึงนามสกุลของไฟล์
    private String getFileExtension(File file) {
        String filename = file.getName();
        int index = filename.lastIndexOf('.');
        if (index > 0) {
            return filename.substring(index + 1).toLowerCase(); // คืนค่านามสกุลของไฟล์
        }
        return ""; // ถ้าไม่มีนามสกุลคืนค่าเป็นสตริงว่าง
    }

    // ฟังก์ชันในการตรวจสอบชนิดของไฟล์
    private void readAndInsertToDatabase(File file) {
        String url = "jdbc:mysql://localhost:3306/inventory";
        String user = "manaji";
        String password = "zoomgik2341";

        String insertQuery = "INSERT INTO `products`(`id`, `name`, `type`, `price`, `stock`, `image`, `status`) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (BufferedReader br = new BufferedReader(new FileReader(file));
             Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            String line;
            boolean isHeader = true;

            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                // แก้ไขจาก split("\t") เป็น split(",") สำหรับ CSV ที่คั่นด้วยคอมม่า
                String[] values = line.split(",");
                if (values.length < 5) {
                    System.out.println("Invalid data format: " + line);
                    continue;
                }
                String productId = generateRandomProductId();
                String name = values[0].trim();
                String type = values[1].trim();
                double price = Double.parseDouble(values[2].trim());
                int stock = Integer.parseInt(values[3].trim());
                String imagePath = values[4].trim();
                String status = calculateStatus(stock); // คำนวณสถานะสินค้า

                File imageFile = new File(imagePath);
                if (!imageFile.exists()) {
                    System.out.println("Image file not found: " + imagePath);
                    continue;
                }
                try (FileInputStream fis = new FileInputStream(imageFile)) {
                    preparedStatement.setString(1, productId);
                    preparedStatement.setString(2, name);
                    preparedStatement.setString(3, type);
                    preparedStatement.setDouble(4, price);
                    preparedStatement.setInt(5, stock);
                    preparedStatement.setBinaryStream(6, fis, (int) imageFile.length());
                    preparedStatement.setString(7, status); // เพิ่มค่าของ status

                    preparedStatement.executeUpdate();
                    logAction(username,"Add Product", name, stock, "Product added to inventory.");
                    System.out.println("Data inserted successfully!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // ฟังก์ชันในการแสดงข้อความแจ้งเตือน
    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    // ฟังก์ชันสำหรับสร้างรหัสสินค้าแบบสุ่ม
    public String generateRandomProductId() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder randomId = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            int randomIndex = random.nextInt(characters.length());
            randomId.append(characters.charAt(randomIndex));
        }
        return randomId.toString();
    }

    // ฟังก์ชันสำหรับคำนวณสถานะสินค้า
    private String calculateStatus(int stock) {
        if (stock == 0) {
            return "Out of Stock";
        } else if (stock < 50) {
            return "Low Stock";
        } else {
            return "Available for Sale";
        }
    }

    private void setupHierarchicalFilter() {
        // เมนูย่อยสำหรับช่วงราคา
        Menu priceMenu = new Menu("Price Range");
        priceMenu.getItems().addAll(
            createMenuItem("Under $500", "price"),
            createMenuItem("$500 - $999", "price"),
            createMenuItem("$1000 - $1999", "price"),
            createMenuItem("$2000+", "price")
        );

        // เมนูย่อยสำหรับสถานะสินค้า
        Menu statusMenu = new Menu("Status");
        Set<String> statuses = new TreeSet<>();
        for (ControlAddproduct product : InventoryList) {
            String status = calculateStatus(product.getStock());
            if (status != null && !status.trim().isEmpty()) {
                statuses.add(status);
            }
        }
        for (String status : statuses) {
            statusMenu.getItems().add(createMenuItem(status, "status"));
        }

        // เมนูย่อยสำหรับประเภทสินค้า
        Menu typeMenu = new Menu("Type");
        Set<String> types = new TreeSet<>();
        for (ControlAddproduct product : InventoryList) {
            String type = product.getType();
            if (type != null && !type.trim().isEmpty()) {
                types.add(type);
            }
        }
        for (String type : types) {
            typeMenu.getItems().add(createMenuItem(type, "type"));
        }

        // เพิ่มเมนูลงใน MenuButton
        filterMenuButton.getItems().clear();
        filterMenuButton.getItems().addAll(priceMenu, statusMenu, typeMenu);
    }

    private MenuItem createMenuItem(String text, String category) {
        MenuItem item = new MenuItem(text);
        item.setOnAction(event -> applyFilter(item)); // ใช้พารามิเตอร์ให้สัมพันธ์

        item.setUserData(category); // Set the category as user data
        return item;
    }

    private FilteredList<ControlAddproduct> filteredData; // Declare globally

    // ฟังก์ชันสำหรับการตั้งค่าฟิลเตอร์
    private void applyFilter(MenuItem selected) {
        String category = (String) selected.getUserData();
        String value = selected.getText();

        filteredData.setPredicate(product -> {
            switch (category) {
                case "price":
                    double price = product.getPrice();
                    if ("Under $500".equals(value)) return price < 500;
                    if ("$500 - $999".equals(value)) return price >= 500 && price < 1000;
                    if ("$1000 - $1999".equals(value)) return price >= 1000 && price < 2000;
                    if ("$2000+".equals(value)) return price >= 2000;
                    break;

                case "status":
                    return calculateStatus(product.getStock()).equals(value);

                case "type":
                    return product.getType().equals(value);

                default:
                    return true;
            }
            return false;
        });

        // รีเฟรช TableView
        Product_Table.refresh();
    }

 // ฟังก์ชันสำหรับการค้นหาข้อมูลในตาราง
    private void setupSearch() {
        // ใช้ FilteredList สำหรับการกรองข้อมูลจาก InventoryList
        filteredData = new FilteredList<>(InventoryList, p -> true);
        // เพิ่ม Listener สำหรับช่องค้นหา
        search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(product -> {
                // ถ้าช่องค้นหาว่าง ให้แสดงข้อมูลทั้งหมด
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                // กรองข้อมูลจากชื่อสินค้า ประเภทสินค้า หรือ ID
                if (product.getName().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // ค้นหาจากชื่อสินค้า
                } else if (product.getType().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // ค้นหาจากประเภทสินค้า
                } else if (product.getId().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // ค้นหาจาก ID สินค้า
                }
                return false; // ไม่ตรงกับข้อมูลใดเลย
            });
        });

        // เชื่อม FilteredList กับ TableView
        Product_Table.setItems(filteredData);
    }
    
    public void start(Stage stage) {
        // Dropdowns for Filters
        ComboBox<String> typeFilter = new ComboBox<>();
        typeFilter.getItems().addAll("All", "Clothing", "Jeans", "Shoes");
        typeFilter.setValue("All");

        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().addAll("All", "Available for Sale", "Low Stock", "Out of Stock");
        statusFilter.setValue("All");

        TextField minPrice = new TextField();
        minPrice.setPromptText("Min Price");

        TextField maxPrice = new TextField();
        maxPrice.setPromptText("Max Price");

        // Event Handlers for Auto Filtering
        typeFilter.setOnAction(e -> applyFilters(typeFilter, statusFilter, minPrice, maxPrice));
        statusFilter.setOnAction(e -> applyFilters(typeFilter, statusFilter, minPrice, maxPrice));
        minPrice.textProperty().addListener((observable, oldValue, newValue) -> 
            applyFilters(typeFilter, statusFilter, minPrice, maxPrice));
        maxPrice.textProperty().addListener((observable, oldValue, newValue) -> 
            applyFilters(typeFilter, statusFilter, minPrice, maxPrice));

        // Layout for Filters
        HBox filterBar = new HBox(10, typeFilter, statusFilter, minPrice, maxPrice);
        filterBar.setPadding(new Insets(10));

        // Root Layout
        VBox root = new VBox(filterBar);
        root.setPadding(new Insets(10));

        // Scene
        Scene scene = new Scene(root, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Inventory Management");
        stage.show();
        
        
    }

    // Method to Handle Filtering Logic
    private void applyFilters(ComboBox<String> typeFilter, ComboBox<String> statusFilter, TextField minPrice, TextField maxPrice) {
        String selectedType = typeFilter.getValue();
        String selectedStatus = statusFilter.getValue();
        String min = minPrice.getText();
        String max = maxPrice.getText();
        
        // Implement Filtering Logic Here
        System.out.println("Type: " + selectedType + ", Status: " + selectedStatus + 
                           ", Price Range: " + min + " - " + max);
    }

    private void filterData2() {
        // กรองข้อมูลใหม่ตามคำค้นหา
        String searchText = search.getText().toLowerCase();

        FilteredList<ControlAddproduct> filteredData = new FilteredList<>(InventoryList, p -> {
            if (searchText == null || searchText.isEmpty()) {
                return true;
            }

            // กรองข้อมูลจากชื่อสินค้า หรือประเภทสินค้า
            return p.getName().toLowerCase().contains(searchText) || p.getType().toLowerCase().contains(searchText) || p.getId().toLowerCase().contains(searchText)
            		|| p.getStatus().toLowerCase().contains(searchText);
        });

        // เชื่อม FilteredList กับ TableView
        Product_Table.setItems(filteredData);
    }
    
	@FXML
	public void initialize() {
		username = UserSession.getInstance().getUsername();
		if (username == null || username.isEmpty()) {
			System.err.println("Username is not set in UserSession.");
			return;
		}

		// ตรวจสอบและเชื่อมต่อกับฐานข้อมูล
		databaseConnector = new connectsql();
		connection = databaseConnector.getConnection();

		if (connection == null) {
			System.err.println("Database connection failed!");
			return;
		}

		// สร้าง FilteredList หลังจากเชื่อมต่อฐานข้อมูล
		filteredData = new FilteredList<>(FXCollections.observableArrayList(loadDataFromDatabase()));

		// ตั้งค่า Event Handler สำหรับปุ่มค้นหา
		search.setOnAction(event -> {
			filterData2();
		});

		// โหลดข้อมูลและตั้งค่าต่าง ๆ
		loadData();
		setupHierarchicalFilter();
		Product_Table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		setupSearch();
		setupColumns();
	}

    // ตัวอย่างเมธอดในการโหลดข้อมูลจากฐานข้อมูล
    private List<ControlAddproduct> loadDataFromDatabase() {
        List<ControlAddproduct> data = new ArrayList<>();
        // โค้ดสำหรับดึงข้อมูลจากฐานข้อมูลและเพิ่มลงใน data
        return data;
    }
    
	public static ImageView loadImageFromDatabase(int id) {
        // สร้าง ImageView เพื่อแสดงภาพ
        ImageView imageView = new ImageView();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // สร้างการเชื่อมต่อกับฐานข้อมูล
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Inventory", "manaji", "zoomgik2341");

            // ตรวจสอบการเชื่อมต่อ
            if (conn != null) {
                System.out.println("Connection to database established successfully!");
            } else {
                System.out.println("Failed to connect to database.");
            }

            // สร้าง SQL query เพื่อดึงข้อมูลภาพ
            String query = "SELECT image FROM products WHERE id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);  // กำหนด id ของข้อมูลที่ต้องการดึง
            rs = stmt.executeQuery();

            if (rs.next()) {
                // ดึงข้อมูลจาก BLOB
            	byte[] imageData = rs.getBytes("image");
            	ByteArrayInputStream bis = new ByteArrayInputStream(imageData);
            	Image image = new Image(bis);

                // กำหนด Image ให้กับ ImageView
                imageView.setImage(image);
                imageView.setFitWidth(100);  // กำหนดขนาดความกว้าง
                imageView.setFitHeight(100); // กำหนดขนาดความสูง
                imageView.setPreserveRatio(true); // คงสัดส่วนของภาพ

                System.out.println("Image loaded successfully from the database.");
            } else {
                System.out.println("No image found for the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("SQL error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return imageView;
    }
    
    private void setupColumns() {
    	
        Productcal.setCellValueFactory(new PropertyValueFactory<>("name"));
        Typscal.setCellValueFactory(new PropertyValueFactory<>("type"));
        Pricecal.setCellValueFactory(new PropertyValueFactory<>("price"));
        Stockcal.setCellValueFactory(new PropertyValueFactory<>("stock"));
        Soldcal.setCellValueFactory(new PropertyValueFactory<>("sold"));
        Statuscal.setCellValueFactory(new PropertyValueFactory<>("status"));
        

        // กำหนด CellValueFactory สำหรับสถานะ
        Statuscal.setCellFactory(new Callback<TableColumn<ControlAddproduct, String>, TableCell<ControlAddproduct, String>>() {
            @Override
            public TableCell<ControlAddproduct, String> call(TableColumn<ControlAddproduct, String> param) {
                return new TableCell<ControlAddproduct, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null) {
                            setGraphic(null);
                        } else {
                            ControlAddproduct product = getTableView().getItems().get(getIndex());
                            String status = calculateStatus(product.getStock()); // ตรวจสอบการคำนวณสถานะ
                            Label label = new Label(status);
                            label.setStyle("-fx-padding: 5 10; -fx-background-radius: 20px; -fx-text-fill: white; -fx-font-weight: bold;");
                            label.setMinWidth(120);
                            label.setPrefWidth(120);
                            label.setMaxWidth(120);
                            label.setAlignment(Pos.CENTER);
                            setStatusColor(status, label);
                            setGraphic(label);
                        }
                    }
                };
            }

            private void setStatusColor(String status, Label label) {
                switch (status) {
                    case "Out of Stock":
                        label.setStyle(label.getStyle() + "-fx-background-color: #FF4322;");
                        break;
                    case "Low Stock":
                        label.setStyle(label.getStyle() + "-fx-background-color: #FFA322;");
                        break;
                    case "Available for Sale":
                        label.setStyle(label.getStyle() + "-fx-background-color: #2DCA5C;");
                        break;
                    default:
                        label.setStyle(label.getStyle() + "-fx-background-color: #BFBFBF;");
                }
            }
        });
     // คอลัมน์สำหรับแสดงภาพ
        Picturecal.setCellValueFactory(new PropertyValueFactory<>("imagePath"));
        Picturecal.setCellFactory(new Callback<TableColumn<ControlAddproduct, String>, TableCell<ControlAddproduct, String>>() {
            @Override
            public TableCell<ControlAddproduct, String> call(TableColumn<ControlAddproduct, String> param) {
                return new TableCell<ControlAddproduct, String>() {
                    private final ImageView imageView = new ImageView();

                    {
                        imageView.setPreserveRatio(true);  // Preserve aspect ratio
                        imageView.setFitWidth(100);        // Set width
                        imageView.setFitHeight(100);       // Set height
                    }

                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null || item.isEmpty()) {
                            setGraphic(null);
                        } else {
                            imageView.setImage(new Image("file:" + item));
                            setGraphic(imageView);

                            // Double-click to open the image in a new window
                            setOnMouseClicked(event -> {
                                if (event.getClickCount() == 2) {
                                    showImageInNewWindow(item, getScene().getWindow());
                                }
                            });
                        }
                    }

                    private void showImageInNewWindow(String imagePath, Window primaryStage) {
                        Stage imageStage = new Stage();
                        imageStage.initModality(Modality.APPLICATION_MODAL); // Block interaction with other windows
                        imageStage.initStyle(StageStyle.TRANSPARENT); // Transparent background

                        // Create a semi-transparent background
                        StackPane backgroundPane = new StackPane();
                        backgroundPane.setStyle("-fx-background-color: rgba(0, 0, 0, 0.25);"); // Black with 25% opacity
                        backgroundPane.setOnMouseClicked(event -> imageStage.close()); // Close when clicking outside

                        // Add ImageView with zoom functionality
                        ImageView largeImageView = new ImageView(new Image("file:" + imagePath));
                        largeImageView.setPreserveRatio(true);
                        largeImageView.setFitWidth(400);
                        largeImageView.setFitHeight(400);

                        // Add scroll event for zooming
                        largeImageView.setOnScroll(event -> {
                            double zoomFactor = 1.1; // Zoom increment
                            if (event.getDeltaY() > 0) {
                                largeImageView.setFitWidth(largeImageView.getFitWidth() * zoomFactor);
                                largeImageView.setFitHeight(largeImageView.getFitHeight() * zoomFactor);
                            } else {
                                largeImageView.setFitWidth(largeImageView.getFitWidth() / zoomFactor);
                                largeImageView.setFitHeight(largeImageView.getFitHeight() / zoomFactor);
                            }
                            event.consume(); // Prevent event propagation
                        });

                        backgroundPane.getChildren().add(largeImageView);

                        // Bind backgroundPane size to match the primary stage size
                        Scene scene = new Scene(backgroundPane, primaryStage.getWidth(), primaryStage.getHeight(), javafx.scene.paint.Color.TRANSPARENT);
                        backgroundPane.prefWidthProperty().bind(primaryStage.widthProperty());
                        backgroundPane.prefHeightProperty().bind(primaryStage.heightProperty());

                        // Set and show the scene
                        imageStage.setScene(scene);
                        imageStage.show();
                    }
                };
            }
        });
        ActionColumn.setCellFactory(new Callback<TableColumn<ControlAddproduct, Void>, TableCell<ControlAddproduct, Void>>() {
            @Override
            public TableCell<ControlAddproduct, Void> call(TableColumn<ControlAddproduct, Void> param) {
                return new TableCell<ControlAddproduct, Void>() {
                    private final Button button = new Button();
                    private final ImageView editIcon = new ImageView(new Image("file:C:\\Users\\zombiman\\eclipse-workspace\\InventoryMM\\รูป\\compose.png"));
               
                    {
                        editIcon.setFitWidth(23);
                        editIcon.setFitHeight(23);
                        button.setGraphic(editIcon);
                        button.setStyle("-fx-background-color: transparent; -fx-padding: 5;");
                        button.setOnAction(e -> {
                            ControlAddproduct product = getTableView().getItems().get(getIndex());
                            System.out.println("Editing product: " + product.getName());
                            openEditDialog(product);
                        });
                    }

                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(button);
                        }
                    }

                    private void openEditDialog(ControlAddproduct product) {
                        Stage dialogStage = new Stage();
                        dialogStage.setTitle("Edit Product"); // Remove window borders
                        dialogStage.initModality(Modality.WINDOW_MODAL);
                        dialogStage.initOwner(Product_Table.getScene().getWindow());

                        // Main container
                        VBox vbox = new VBox(15);
                        vbox.setPadding(new Insets(20));
                        vbox.setAlignment(Pos.CENTER);
                        vbox.setStyle("-fx-background-color: linear-gradient(to bottom, #ffe8e8, #ffcce7);");

                        // Title
                        Label titleLabel = new Label("Edit Product");
                        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #6d0037;");

                        // Fields for editing
                        TextField nameField = new TextField(product.getName());
                        nameField.setPromptText("Enter Product Name");
                        nameField.setPrefWidth(300);
                        nameField.setStyle("-fx-border-color: #d4a5a5; -fx-border-radius: 5px;");

                        TextField typeField = new TextField(product.getType());
                        typeField.setPromptText("Enter Product Type");
                        typeField.setPrefWidth(300);
                        typeField.setStyle("-fx-border-color: #d4a5a5; -fx-border-radius: 5px;");

                        TextField priceField = new TextField(String.valueOf(product.getPrice()));
                        priceField.setPromptText("Enter Price");
                        priceField.setPrefWidth(300);
                        priceField.setStyle("-fx-border-color: #d4a5a5; -fx-border-radius: 5px;");

                        TextField stockField = new TextField(String.valueOf(product.getStock()));
                        stockField.setPromptText("Enter Stock");
                        stockField.setPrefWidth(300);
                        stockField.setStyle("-fx-border-color: #d4a5a5; -fx-border-radius: 5px;");

                        // Image-related fields
                        TextField imagePathField = new TextField(product.getImagePath());
                        imagePathField.setPromptText("Enter Image Path");
                        imagePathField.setPrefWidth(300);
                        imagePathField.setStyle("-fx-border-color: #d4a5a5; -fx-border-radius: 5px;");

                        ImageView imageView = new ImageView(new Image("file:" + product.getImagePath()));
                        imageView.setFitWidth(100);
                        imageView.setFitHeight(100);
                        imageView.setPreserveRatio(true);

                        Button browseButton = new Button("Browse");
                        browseButton.setStyle("-fx-background-color: #FFFFFF; -fx-text-fill: #6d0037; -fx-border-radius: 5px; -fx-background-radius: 5px;-fx-border-color: #d4a5a5;");
                        browseButton.setOnAction(e -> {
                            FileChooser fileChooser = new FileChooser();
                            fileChooser.getExtensionFilters().addAll(
                                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
                            );
                            File selectedFile = fileChooser.showOpenDialog(dialogStage);
                            if (selectedFile != null) {
                                imagePathField.setText(selectedFile.getAbsolutePath());
                                imageView.setImage(new Image("file:" + selectedFile.getAbsolutePath()));
                            }
                        });

                        // Buttons for saving or canceling
                        HBox buttonBox = new HBox(10);
                        buttonBox.setAlignment(Pos.CENTER);

                        Button saveButton = new Button("Save");
                        saveButton.setStyle("-fx-background-color: #c97aa8; -fx-text-fill: white; -fx-font-weight: bold; -fx-border-radius: 5px; -fx-background-radius: 5px;");
                        saveButton.setOnAction(e -> {
                            product.setName(nameField.getText());
                            product.setType(typeField.getText());
                            product.setPrice(Double.parseDouble(priceField.getText()));
                            product.setStock(Integer.parseInt(stockField.getText()));
                            product.setImagePath(imagePathField.getText()); // Save new image path

                            updateProductInDatabase(product);
                            loadData();
                            dialogStage.close();
                        });

                        Button cancelButton = new Button("Cancel");
                        cancelButton.setStyle("-fx-background-color: #e9e9e9; -fx-text-fill: #6d0037; -fx-font-weight: bold; -fx-border-radius: 5px; -fx-background-radius: 5px;");
                        cancelButton.setOnAction(e -> dialogStage.close());

                        buttonBox.getChildren().addAll(saveButton, cancelButton);

                        // Layout
                        vbox.getChildren().addAll(
                            titleLabel,
                            new VBox(5, new Label("Name:"), nameField),
                            new VBox(5, new Label("Type:"), typeField),
                            new VBox(5, new Label("Price:"), priceField),
                            new VBox(5, new Label("Stock:"), stockField),
                            new VBox(5, new Label("Image:"), imagePathField, browseButton),
                            imageView,
                            buttonBox
                        );

                        Scene scene = new Scene(vbox);
                        dialogStage.setScene(scene);
                        dialogStage.showAndWait();
                    }
                    
					private void updateProductInDatabase(ControlAddproduct product) {
					    // Update SQL query to include image column as LONGBLOB
					    String query = "UPDATE products SET name = ?, type = ?, price = ?, stock = ?, sold = ?, status = ?, image = ? WHERE id = ?";
					
					    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
					        pstmt.setString(1, product.getName());
					        pstmt.setString(2, product.getType());
					        pstmt.setDouble(3, product.getPrice());
					        pstmt.setInt(4, product.getStock());
					        pstmt.setInt(5, product.getSold());
					
					        // Calculate the new status based on the stock
					        String newStatus = calculateStatus(product.getStock());
					        pstmt.setString(6, newStatus);
					
					        // Convert image to byte array and set it for LONGBLOB column
					        try (FileInputStream fis = new FileInputStream(product.getImagePath())) {
					            byte[] imageBytes = new byte[fis.available()];
					            fis.read(imageBytes);
					            pstmt.setBytes(7, imageBytes);
					        } catch (IOException e) {
					            System.err.println("Error reading image data: " + e.getMessage());
					        }
					
					        pstmt.setString(8, product.getId()); // Update the WHERE clause with the product ID
					
					        int rowsAffected = pstmt.executeUpdate();
					        logAction(username,"Update Product", product.getName(), product.getStock(), "Product details updated.");
					        if (rowsAffected > 0) {
					            System.out.println("Product updated successfully!");
					        } else {
					            System.out.println("No product found with the specified ID.");
					        }
					    } catch (SQLException e) {
					        System.err.println("Error updating product: " + e.getMessage());
					    }
					}
					
                };
            }
        });
    }

	private void loadData() {
		InventoryList.clear(); // ล้างข้อมูลเก่าจาก InventoryList
		String query = "SELECT * FROM products";

		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet resultSet = pstmt.executeQuery()) {

			while (resultSet.next()) { // ใช้ while เพื่อดึงข้อมูลทุกแถว
				byte[] imageBytes = resultSet.getBytes("image");
				String tempImagePath = saveImageToTempFile(imageBytes); // บันทึกรูปเป็นไฟล์ชั่วคราว
				ControlAddproduct product = new ControlAddproduct(resultSet.getString("id"),
						resultSet.getString("name"), resultSet.getString("type"), resultSet.getDouble("price"),
						resultSet.getInt("stock"), resultSet.getInt("sold"), resultSet.getString("status"),
						tempImagePath // เก็บพาธของไฟล์ชั่วคราวแทน byte[]
				);
				InventoryList.add(product);
			}

			// เรียงลำดับ InventoryList โดยใช้ timestamp หรือฟิลด์ที่เกี่ยวข้อง
			FXCollections.sort(InventoryList, (p1, p2) -> p2.getTimestamp().compareTo(p1.getTimestamp()));

			Product_Table.setItems(InventoryList); // รีเฟรชข้อมูลในตาราง
			System.out.println("Finished loading data");

		} catch (SQLException e) {
			System.err.println("Error loading data: " + e.getMessage());
		}
	}

    private void loadData2() {
        InventoryList.clear();  // Clear old data from InventoryList
        String query = "SELECT * FROM products";

        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet resultSet = pstmt.executeQuery()) {

            while (resultSet.next()) {  // Use while to fetch all rows
                byte[] imageBytes = resultSet.getBytes("image");
                String tempImagePath = saveImageToTempFile(imageBytes);  // Save image to temporary file

                ControlAddproduct product = new ControlAddproduct(
                    resultSet.getString("id"),
                    resultSet.getString("name"),
                    resultSet.getString("type"),
                    resultSet.getDouble("price"),
                    resultSet.getInt("stock"),
                    resultSet.getInt("sold"),
                    resultSet.getString("status"),
                    tempImagePath  // Store path of the temporary image file
                );
                InventoryList.add(product);
            }
         // Sort InventoryList by timestamp
            FXCollections.sort(InventoryList, (p1, p2) -> p2.getTimestamp().compareTo(p1.getTimestamp()));
            // Debugging: Print out the number of products loaded
            System.out.println("Number of products loaded: " + InventoryList.size());

            // Initialize filteredData with the latest data in InventoryList
            filteredData = new FilteredList<>(InventoryList);

            Product_Table.setItems(filteredData);  // Refresh table with InventoryList data
            Product_Table.refresh();  // Force refresh to ensure the UI updates

        } catch (SQLException e) {
            System.err.println("Error loading data: " + e.getMessage());
        }
    }


    private String saveImageToTempFile(final byte[] imageBytes) {
        if (imageBytes == null || imageBytes.length == 0) {
            System.err.println("Invalid image data.");
            return null;
        }
        try {
            // สร้างไฟล์ชั่วคราวในโฟลเดอร์ temp
            File tempFile = File.createTempFile("product_image_", ".png");
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(imageBytes);
            }
            // คืนค่าพาธของไฟล์ชั่วคราว
            return tempFile.getAbsolutePath();
        } catch (IOException e) {
            System.err.println("Error saving image to temporary file: " + e.getMessage());
            return null;
        }
    }

    public void deleteTempFiles() {
        File tempDir = new File(System.getProperty("java.io.tmpdir"));
        File[] tempFiles = tempDir.listFiles((dir, name) -> name.startsWith("product_image_") && name.endsWith(".png"));

        if (tempFiles != null) {
            for (File tempFile : tempFiles) {
                if (tempFile.delete()) {
                    System.out.println("Deleted temp file: " + tempFile.getAbsolutePath());
                } else {
                    System.err.println("Failed to delete temp file: " + tempFile.getAbsolutePath());
                }
            }
        }
    }
    
    @FXML
    private void handleDeleteSelected() {
        // ดึงรายการที่ถูกเลือก
        ObservableList<ControlAddproduct> selectedProducts = Product_Table.getSelectionModel().getSelectedItems();

        if (selectedProducts.isEmpty()) {
            System.out.println("No products selected for deletion.");
            return;
        }

        // สร้างข้อความยืนยัน
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Are you sure you want to delete the selected products?");
        confirmationAlert.setContentText("Deleting " + selectedProducts.size() + " products cannot be undone.");

        // แสดงข้อความยืนยันและรอผลลัพธ์
        Optional<ButtonType> result = confirmationAlert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            // หากผู้ใช้กดยืนยัน (OK)
            System.out.println("Deleting " + selectedProducts.size() + " products.");

            // ลบจากฐานข้อมูลและ ObservableList
            for (ControlAddproduct product : new ArrayList<>(selectedProducts)) {
                deleteProductFromDatabase(product.getId()); // ลบจากฐานข้อมูล
                InventoryList.remove(product);             // ลบจาก ObservableList

                // Log the deletion action, use product.getName() to log the name of the deleted product
                logAction(username,"Delete Product", product.getName(), 0, "Product deleted from inventory.");
            }

            // อัปเดต TableView
            Product_Table.getSelectionModel().clearSelection();
            Product_Table.refresh();
        } else {
            // หากผู้ใช้กด Cancel หรือปิดหน้าต่าง
            System.out.println("Deletion cancelled.");
        }
    }

    // เมธอดสำหรับลบข้อมูลในฐานข้อมูล
    private void deleteProductFromDatabase(String productId) {
        String query = "DELETE FROM products WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, productId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product with ID " + productId + " deleted successfully.");
            } else {
                System.out.println("No product found with ID " + productId);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting product: " + e.getMessage());
        }
    }
    
    // เมธอดบันทึก Log
    public void logAction(String username, String action, String productName, int quantity, String notes) {
		if (username == null || username.isEmpty()) {
			System.err.println("Username is not set. Unable to log action.");
			return;
		}

		if (connection == null) {
			System.err.println("Connection is not initialized.");
			return;
		}
		String query = "INSERT INTO report_table (timestamp, user, action, product_name, quantity, notes) VALUES (CURRENT_TIMESTAMP, ?, ?, ?, ?, ?)";

		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			stmt.setString(2, action);
			stmt.setString(3, productName);
			stmt.setInt(4, quantity);
			stmt.setString(5, notes);

			System.out.println("Executing log query: " + stmt.toString()); // Debug statement

			int rowsAffected = stmt.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("Log saved successfully.");
			} else {
				System.out.println("Failed to save log.");
			}
		} catch (SQLException e) {
			System.err.println("Error logging action: " + e.getMessage());
			e.printStackTrace(); // Print stack trace for debugging
		}
	}
    
    @FXML
    private void Get_ADDview(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Addproduct.fxml"));
        Parent addProductView = loader.load();
        ControlAddproduct controller = loader.getController();
        controller.setConnection(connection); // ต้องแน่ใจว่ามี connection object พร้อมใช้งาน
        Stage stage = new Stage();
        stage.setTitle("Add New Product");
        stage.setScene(new Scene(addProductView));
        stage.show();
    }
    
    @FXML
    void Logoutbutton(MouseEvent event) throws IOException{
    	Parent root = FXMLLoader.load(getClass().getResource("/Login/login.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
 
    @FXML
    private void dashboard_button(ActionEvent event) throws IOException {
        switchScene(event, "main.fxml");
    }

    @FXML
    private void report_button(ActionEvent event) throws IOException {
        switchScene(event, "reports.fxml");
    }

    @FXML
    private void Saler_button (ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/application/saler.fxml"));
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow(); 
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void closeConnection() {
    	deleteTempFiles();  // ลบไฟล์ชั่วคราวทั้งหมด
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
    @FXML
    private void handleRefreshButton(ActionEvent event) {
        loadData();
    }
    
    @FXML
    void DeleteTable(MouseEvent event) {
    	handleDeleteSelected();
    	
    }
    
    public void refreshTable() {
        loadData2();
    }
   
}
