package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Random;

import Login.UserSession;

public class ControlAddproduct {

    @FXML
    private TextField imagePathField;
    @FXML
    private ComboBox<String> typeComboBox;
    @FXML
    private TextField nameField;
    @FXML
    private TextField priceField;
    @FXML
    private TextField stockField;
    @FXML
    private ImageView imageView;
    @FXML
    private ImageView imagePreview;
    @FXML
    private Button saveproduct;
    private Connection connection;
    
    private String id;
    private String name;
    private String type;
    private double price;
    private int stock;
    private int sold;
    private String status;
    private String imagePath;  // Path to the temporary image file
    private LocalDateTime timestamp; // Add this field
	private String username;

    public ControlAddproduct() {
    }
    
    public ControlAddproduct(String id, String name, String type, double price, int stock, int sold, String status, String imagePath) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.price = price;
        this.stock = stock;
        this.sold = sold;
        this.status = status;
        this.imagePath = imagePath;
        this.timestamp = LocalDateTime.now(); // Initialize timestamp
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

	public void initialize() {
		username = UserSession.getInstance().getUsername();
		if (username == null || username.isEmpty()) {
			System.err.println("Username is not set in UserSession.");
			return;
		}
		ObservableList<String> productTypes = FXCollections.observableArrayList();
		connectsql dbConnection = new connectsql();

		try (Connection conn = dbConnection.getConnection()) {
			String query = "SELECT DISTINCT type FROM products";
			try (PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					String type = rs.getString("type");
					productTypes.add(type);
				}
			}
		} catch (Exception e) {
			showAlert("Error", "Error fetching product types: " + e.getMessage(), Alert.AlertType.ERROR);
		}

		typeComboBox.setItems(productTypes);
		if (!productTypes.isEmpty()) {
			typeComboBox.setValue(productTypes.get(0));
		}
	}

	public String generateRandomProductId() {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuilder randomId = new StringBuilder();

		for (int i = 0; i < 5; i++) {
			int randomIndex = random.nextInt(characters.length());
			randomId.append(characters.charAt(randomIndex));
		}
		return randomId.toString();
	}

    @FXML
    public void handleBrowseButtonAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg");
        fileChooser.getExtensionFilters().add(extFilter);

        Stage stage = (Stage) imagePathField.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            String imagePath = selectedFile.getAbsolutePath();
            imagePathField.setText(imagePath);
            Image image = new Image("file:" + imagePath);
            imagePreview.setImage(image);
        }
    }

	@FXML
	private void handleSaveButtonAction(ActionEvent event) {
		if (!validateInputs()) {
			showError("Invalid Input", "Please check your input values.");
			return;
		}

		String id = generateRandomProductId();
		String name = nameField.getText().trim();
		String type = typeComboBox.getValue();
		double price = 0;
		int stock = 0;

		try {
			price = Double.parseDouble(priceField.getText().trim());
			stock = Integer.parseInt(stockField.getText().trim());
		} catch (NumberFormatException e) {
			showError("Invalid Number", "Price and stock must be valid numbers.");
			return;
		}

		byte[] imageData = null;
		try {
			File imageFile = new File(imagePathField.getText().trim());
			if (!imageFile.exists()) {
				showError("File Error", "The specified image file does not exist.");
				return;
			}
			try (FileInputStream fis = new FileInputStream(imageFile)) {
				imageData = fis.readAllBytes();
			}
		} catch (IOException e) {
			showError("File Error", "Failed to read image file: " + e.getMessage());
			return;
		}

		String status = calculateProductStatus(stock);

		if (saveProductToDatabase(id, name, type, price, stock, status, imageData)) {
			logAction(username, "Add Product", name, stock, "Product added to inventory."); // Replace "username" with // the actual username
																							
			showSuccess("Product Saved", "Product has been successfully added to inventory.");
			closeWindow();
		}
	}

    private boolean validateInputs() {
        return !nameField.getText().isEmpty() && 
               priceField.getText().matches("\\d+(\\.\\d+)?") && 
               stockField.getText().matches("\\d+");
    }

	private boolean saveProductToDatabase(String id, String name, String type, double price, int stock, String status,
			byte[] imageData) {
		String insertQuery = "INSERT INTO products (id, name, type, price, stock, status, image, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

		try (PreparedStatement pstmt = connection.prepareStatement(insertQuery)) {
			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, type);
			pstmt.setDouble(4, price);
			pstmt.setInt(5, stock);
			pstmt.setString(6, status);
			pstmt.setBytes(7, imageData);

			System.out.println("Executing query: " + pstmt.toString()); // Debug statement

			boolean result = pstmt.executeUpdate() > 0;
			if (result) {
				
			}
			return result;
		} catch (SQLException e) {
			showError("Database Error", "Failed to save product: " + e.getMessage());
			e.printStackTrace(); // Print stack trace for debugging
			return false;
		}
	}

	public void logAction(String username, String action, String productName, int quantity, String notes) {
		if (username == null || username.isEmpty()) {
			System.err.println("Username is not set. Unable to log action.");
			return;
		}

		if (connection == null) {
			System.err.println("Connection is not initialized.");
			return;
		}
		String query = "INSERT INTO report_table (timestamp, user, action, product_name, quantity, notes) VALUES (CURRENT_TIMESTAMP, ?, ?, ?, ?, ?)";

		try (PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, username);
			stmt.setString(2, action);
			stmt.setString(3, productName);
			stmt.setInt(4, quantity);
			stmt.setString(5, notes);

			System.out.println("Executing log query: " + stmt.toString()); // Debug statement

			int rowsAffected = stmt.executeUpdate();
			if (rowsAffected > 0) {
				System.out.println("Log saved successfully.");
			} else {
				System.out.println("Failed to save log.");
			}
		} catch (SQLException e) {
			System.err.println("Error logging action: " + e.getMessage());
			e.printStackTrace(); // Print stack trace for debugging
		}
	}
	
	private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }

    private String calculateProductStatus(int stock) {
        if (stock == 0) return "Out of Stock";
        else if (stock <= 30) return "Low Stock";
        else return "Available for Sale";
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

//    public byte[] getImageData() {
//        if (imagePath != null) {
//            try {
//                // อ่านข้อมูลจากไฟล์
//                return Files.readAllBytes(Paths.get(imagePath));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return null;
//    }
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter and Setter for imagePath
    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
 // สมมติว่ามีฟิลด์ที่เก็บจำนวนสต็อกสินค้า
    private int currentStock;  // จำนวนสต็อกสินค้า

    // คอนสตรัคเตอร์หรือฟังก์ชันอื่นๆ ที่ใช้ตั้งค่า currentStock
    public ControlAddproduct(String name, int stock) {
        this.name = name;
        this.currentStock = stock;  // กำหนดจำนวนสต็อกสินค้าตามที่ได้รับ
    }

    // ฟังก์ชัน getter สำหรับ currentStock
    public int getCurrentStock() {
        return currentStock;
    }

    // ฟังก์ชัน setter ถ้าต้องการ
    public void setCurrentStock(int stock) {
        this.currentStock = stock;
    }

	public int getProductId() {
		// TODO Auto-generated method stub
		return 0;
	}

}