
package application;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import Login.UserSession;
import javafx.scene.control.TableCell;
import javafx.util.Callback;
import javafx.geometry.Pos;

public class ControlReports {
	@FXML
	private TableView<ControlReports> reportTable;
	@FXML
	private TableColumn<ControlReports, String> timestampColumn;
	@FXML
	private TableColumn<ControlReports, String> actionColumn;
	@FXML
	private TableColumn<ControlReports, String> productColumn;
	@FXML
	private TableColumn<ControlReports, Integer> quantityColumn;
	@FXML
	private TableColumn<ControlReports, String> notesColumn;

	private ObservableList<ControlReports> logData = FXCollections.observableArrayList();
	private Connection connection;
	private connectsql databaseConnector;
	private String username;

	@FXML
	public void initialize() {
	    databaseConnector = new connectsql();
	    connection = databaseConnector.getConnection();
	    setupColumns();

	    // Get the username from the session
	    username = UserSession.getInstance().getUsername();

	    if (username != null) {
	        loadLogs(username); // Filter logs for the logged-in user
	    } else {
	        System.out.println("No user logged in.");
	        // You may want to show an alert in the UI indicating that the user is not logged in
	    }
	}

	@FXML
	private void ExportReport(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save Report");
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
		File file = fileChooser.showSaveDialog(reportTable.getScene().getWindow());

		if (file != null) {
			try (BufferedWriter writer = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(file), "UTF-8"))) {
				writer.write("Timestamp,Action,Product Name,Quantity,Notes\n");
				for (ControlReports log : logData) {
					writer.write(String.format("%s,%s,%s,%d,%s\n", log.getTimestamp(), log.getAction(),
							log.getProductName(), log.getQuantity(), log.getNotes()));
				}
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Export Successful");
				alert.setHeaderText(null);
				alert.setContentText("Report exported successfully!");
				alert.showAndWait();
			} catch (IOException e) {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Export Error");
				alert.setHeaderText(null);
				alert.setContentText("Failed to export report: " + e.getMessage());
				alert.showAndWait();
			}
		}
	}
	// In the addLog method
	public void addLog(String action, String productName, int quantity, String notes) {
	    String query = "INSERT INTO report_table (timestamp, action, product_name, quantity, notes, user) VALUES (NOW(), ?, ?, ?, ?, ?)";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, action);
	        stmt.setString(2, productName);
	        stmt.setInt(3, quantity);
	        stmt.setString(4, notes);
	        // Get the username from the session and add it to the query
	        String currentUser = UserSession.getInstance().getUsername();
	        stmt.setString(5, currentUser);
	        stmt.executeUpdate();
	        loadLogs(currentUser); // Load logs for the current user
	    } catch (SQLException e) {
	        System.err.println("Error adding log: " + e.getMessage());
	    }
	}


	private void loadLogs(String currentUser) {
	    logData.clear();
	    String query = "SELECT * FROM report_table WHERE user = ? ORDER BY timestamp DESC";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, currentUser); // กำหนดค่า parameter สำหรับ user
	        try (ResultSet rs = stmt.executeQuery()) {
	            while (rs.next()) {
	                logData.add(new ControlReports(
	                    rs.getString("timestamp"),
	                    rs.getString("action"),
	                    rs.getString("product_name"),
	                    rs.getInt("quantity"),
	                    rs.getString("notes")
	                ));
	            }
	        }
	    } catch (SQLException e) {
	        System.err.println("Error loading logs: " + e.getMessage());
	    }
	}


	@FXML
	void printReport(ActionEvent event) {
		PrinterJob job = PrinterJob.createPrinterJob();
		if (job != null && job.showPrintDialog(reportTable.getScene().getWindow())) {
			boolean success = job.printPage(reportTable);
			if (success) {
				job.endJob();
			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("Print Error");
				alert.setHeaderText(null);
				alert.setContentText("Failed to print the report.");
				alert.showAndWait();
			}
		}
	}

	@FXML
	private void Saler_button(ActionEvent event) {
		try {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			double width = stage.getWidth();
			double height = stage.getHeight();

			FXMLLoader loader = new FXMLLoader(getClass().getResource("saler.fxml"));
			Parent root = loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			stage.setScene(scene);
			stage.setWidth(width); // Set original width
			stage.setHeight(height); // Set original height
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void Inventory_button(ActionEvent event) {
		try {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			double width = stage.getWidth();
			double height = stage.getHeight();

			FXMLLoader loader = new FXMLLoader(getClass().getResource("Inventory.fxml"));
			Parent root = loader.load();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			stage.setScene(scene);
			stage.setWidth(width); // Set original width
			stage.setHeight(height); // Set original height
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void setupColumns() {
		timestampColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
		actionColumn.setCellValueFactory(new PropertyValueFactory<>("action"));
		productColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
		quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
		notesColumn.setCellValueFactory(new PropertyValueFactory<>("notes"));

		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		Callback<TableColumn<ControlReports, String>, TableCell<ControlReports, String>> stringCellFactory = new Callback<TableColumn<ControlReports, String>, TableCell<ControlReports, String>>() {
			@Override
			public TableCell<ControlReports, String> call(TableColumn<ControlReports, String> column) {
				return new TableCell<ControlReports, String>() {
					@Override
					protected void updateItem(String item, boolean empty) {
						super.updateItem(item, empty);
						if (empty || item == null) {
							setText(null);
						} else {
							if (column == timestampColumn) {
								LocalDateTime dateTime = LocalDateTime.parse(item, inputFormatter);
								setText(dateTime.format(outputFormatter));
							} else {
								setText(item);
							}
						}
						setAlignment(Pos.CENTER); // Center align text
					}
				};
			}
		};

		Callback<TableColumn<ControlReports, Integer>, TableCell<ControlReports, Integer>> integerCellFactory = new Callback<TableColumn<ControlReports, Integer>, TableCell<ControlReports, Integer>>() {
			@Override
			public TableCell<ControlReports, Integer> call(TableColumn<ControlReports, Integer> column) {
				return new TableCell<ControlReports, Integer>() {
					@Override
					protected void updateItem(Integer item, boolean empty) {
						super.updateItem(item, empty);
						if (empty || item == null) {
							setText(null);
						} else {
							setText(item.toString());
						}
						setAlignment(Pos.CENTER); // Center align text
					}
				};
			}
		};

		timestampColumn.setCellFactory(stringCellFactory);
		actionColumn.setCellFactory(stringCellFactory);
		productColumn.setCellFactory(stringCellFactory);
		quantityColumn.setCellFactory(integerCellFactory);

		reportTable.setItems(logData);
	}
	
	@FXML
    void Logoutbutton(MouseEvent event) throws IOException{
    	Parent root = FXMLLoader.load(getClass().getResource("/Login/login.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }
	
	@FXML
	private void report_button(ActionEvent event) {
		// Add navigation logic
	}

	// Fields in ControlReports used in TableView
	private String timestamp;
	private String action;
	private String productName;
	private int quantity;
	private String notes;

	// Constructor with parameters
	public ControlReports(String timestamp, String action, String productName, int quantity, String notes) {
		this.timestamp = timestamp;
		this.action = action;
		this.productName = productName;
		this.quantity = quantity;
		this.notes = notes;
	}

	// Default constructor (needed for FXMLLoader)
	public ControlReports() {
	}

	// Getters and Setters
	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
}
