package application;
import java.sql.Connection;
import java.sql.DriverManager;

public class connectsql {
    private Connection databaseLink;

    public Connection getConnection() {
        String databasename = "inventory";
        String databaseuser = "manaji";
        String databasepassword = "zoomgik2341";
        String url = "jdbc:mysql://localhost:3306/" + databasename + "?useSSL=false&serverTimezone=UTC";

        try {
            // โหลด MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            databaseLink = DriverManager.getConnection(url, databaseuser, databasepassword);
            System.out.println("Connection successful.");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL Driver not found.");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }

        return databaseLink;
    }

    public void closeConnection() {
        try {
            // ตรวจสอบว่า databaseLink ไม่เป็น null และยังไม่ปิดก่อนที่จะปิดการเชื่อมต่อ
            if (databaseLink != null && !databaseLink.isClosed()) {
                databaseLink.close();
                System.out.println("Connection closed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
