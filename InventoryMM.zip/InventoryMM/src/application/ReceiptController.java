package application;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.print.PrinterJob;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class ReceiptController {

    @FXML
    private TableView<ReportRow> reportTable;

    @FXML
    private TableColumn<ReportRow, String> dateColumn;

    @FXML
    private TableColumn<ReportRow, String> productNameColumn;

    @FXML
    private TableColumn<ReportRow, String> customerNameColumn;

    @FXML
    private TableColumn<ReportRow, Integer> quantityColumn;

    @FXML
    private TableColumn<ReportRow, Double> priceColumn;

    @FXML
    private TableColumn<ReportRow, Double> amountColumn;

    @FXML
    private Label totalAmountLabel;

    @FXML
    private Label dateRangeLabel;

    @FXML
    private VBox receiptContent;

    public void initialize() {
        // ตั้งค่าคอลัมน์ TableView
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
    }

    public void setReportData(ObservableList<ReportRow> data) {
        reportTable.setItems(data);
        // คำนวณยอดรวม
        double total = data.stream().mapToDouble(ReportRow::getAmount).sum();
        totalAmountLabel.setText("Total: " + String.format("%.2f", total));
    }

    public void setDateRange(String startDate, String endDate) {
        dateRangeLabel.setText("From " + startDate + " To " + endDate);
    }

    @FXML
    private void printReceipt() {
        PrinterJob printerJob = PrinterJob.createPrinterJob();

        if (printerJob != null) {
            // แสดง Print Dialog
            if (printerJob.showPrintDialog(receiptContent.getScene().getWindow())) {
                // พิมพ์ใบเสร็จหลังจากผู้ใช้กด OK
                boolean success = printerJob.printPage(receiptContent); // ใช้ Node ที่ต้องการพิมพ์
                if (success) {
                    printerJob.endJob();
                    System.out.println("Receipt printed successfully.");
                } else {
                    System.out.println("Failed to print the receipt.");
                }
            }
        } else {
            System.out.println("No printer found or unable to create PrinterJob.");
        }
    }


    // คลาสสำหรับข้อมูลใน TableView
    public static class ReportRow {
        private String date;
        private String productName;
        private String customerName;
        private int quantity;
        private double price;
        private double amount;

        public ReportRow(String date, String productName, String customerName, int quantity, double price, double amount) {
            this.date = date;
            this.productName = productName;
            this.customerName = customerName;
            this.quantity = quantity;
            this.price = price;
            this.amount = amount;
        }

        public String getDate() {
            return date;
        }

        public String getProductName() {
            return productName;
        }

        public String getCustomerName() {
            return customerName;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getPrice() {
            return price;
        }

        public double getAmount() {
            return amount;
        }
    }
}
