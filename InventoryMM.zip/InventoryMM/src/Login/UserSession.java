package Login;

public class UserSession {
    private static UserSession instance; // Instance เดียวของคลาส
    private String username;

    // ทำให้ constructor เป็น private เพื่อไม่ให้สร้าง instance ใหม่
    private UserSession() {}

    // Method สำหรับดึง instance เดียว
    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    // Getter และ Setter สำหรับ username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}