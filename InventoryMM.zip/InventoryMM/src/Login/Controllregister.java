
package Login;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javafx.event.ActionEvent;

public class Controllregister {

	@FXML
	private TextField gmailField;

	@FXML
	private TextField usernameTextField;

	@FXML
	private PasswordField passwordpasswordField;

	@FXML
	private TextField nameField;

	@FXML
	private Label loginMessageLabel;

	@FXML
	private CheckBox jobPositionField1;

	@FXML
	private CheckBox jobpositionFiald2;

	@FXML
	void initialize() {
		jobPositionField1.setOnAction(event -> {
			if (jobPositionField1.isSelected()) {
				jobpositionFiald2.setSelected(false);
			}
		});

		jobpositionFiald2.setOnAction(event -> {
			if (jobpositionFiald2.isSelected()) {
				jobPositionField1.setSelected(false);
			}
		});
	}


	@FXML
	void registerButtonOnAction(ActionEvent event) throws IOException {
		String name = nameField.getText();
		String username = usernameTextField.getText();
		String password = passwordpasswordField.getText();
		String gmail = gmailField.getText();
		String jobPosition = jobPositionField1.isSelected() ? "Manager" : jobpositionFiald2.isSelected() ? "Staff" : "";

		if (name.isEmpty() || username.isEmpty() || password.isEmpty() || gmail.isEmpty() || jobPosition.isEmpty()) {
			loginMessageLabel.setStyle("-fx-text-fill: red;");
			loginMessageLabel.setText("Please fill in all fields!");
			return;
		}

		// Validate Gmail address
		if (!gmail.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$")) {
			loginMessageLabel.setStyle("-fx-text-fill: red;");
			loginMessageLabel.setText("Please enter a valid Gmail address!");
			return;
		}

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory", "manaji",
				"zoomgik2341")) {
			String checkSql = "SELECT COUNT(*) FROM user WHERE username = ?";
			PreparedStatement checkStmt = con.prepareStatement(checkSql);
			checkStmt.setString(1, username);
			var resultSet = checkStmt.executeQuery();
			resultSet.next();

			if (resultSet.getInt(1) > 0) {
				loginMessageLabel.setStyle("-fx-text-fill: red;");
				loginMessageLabel.setText("This username is already taken. Please choose another.");
				return;
			}

			String insertSql = "INSERT INTO user (Name, username, password, jobPosition, Gmail) VALUES (?, ?, ?, ?, ?)";
			PreparedStatement insertStmt = con.prepareStatement(insertSql);
			insertStmt.setString(1, name);
			insertStmt.setString(2, username);
			insertStmt.setString(3, password);
			insertStmt.setString(4, jobPosition);
			insertStmt.setString(5, gmail);

			if (insertStmt.executeUpdate() > 0) {
				loginMessageLabel.setStyle("-fx-text-fill: green;");
				loginMessageLabel.setText("Registration successful!");
				clearFields();

				// Show success popup
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setTitle("Registration Successful");
				alert.setHeaderText(null);
				alert.setContentText("Registration completed successfully!");
				alert.showAndWait();
			}
		} catch (Exception e) {
			loginMessageLabel.setStyle("-fx-text-fill: red;");
			loginMessageLabel.setText("Error: Unable to register.");
			e.printStackTrace(); // Print the exception stack trace for debugging
		}
		
	}


	@FXML
	void loginButtonOnAction(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Login/login.fxml"));
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	private void clearFields() {
		nameField.clear();
		usernameTextField.clear();
		passwordpasswordField.clear();
		gmailField.clear();
		jobPositionField1.setSelected(false);
		jobpositionFiald2.setSelected(false);
	}
}
