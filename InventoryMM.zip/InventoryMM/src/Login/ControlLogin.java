package Login;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import javafx.scene.input.MouseEvent;

import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.scene.control.Label;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import application.connectsql;

public class ControlLogin {
	  
@FXML
private Text forgetpassword;

@FXML
private Button loginButton;

@FXML
private Label loginMessageLabel;

@FXML
private PasswordField passwordpasswordField;

@FXML
private TextField usernameTextField;

@FXML
private Button registerButton;

@FXML
void loginButtonOnAction(ActionEvent e) throws IOException {
    if (!usernameTextField.getText().isBlank() && !passwordpasswordField.getText().isBlank()) {
        validateLogin(e); 
    } else {
        loginMessageLabel.setText("Please enter username and password");
    }
}
@FXML
void registerButtonOnAction(ActionEvent event) throws IOException {
	Parent root = FXMLLoader.load(getClass().getResource("registers.fxml"));
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow(); 
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}

@FXML
void forgetpasswordOnAction(MouseEvent  event) throws IOException{
	Parent root = FXMLLoader.load(getClass().getResource("/Login/Forgetpassword.fxml"));
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow(); 
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}

private void validateLogin(ActionEvent event) {
    connectsql connectNow = new connectsql();
    Connection connectDB = connectNow.getConnection();

    String verifyLogin = "SELECT jobPosition FROM user WHERE username = ? AND password = ?";
    try (PreparedStatement preparedStatement = connectDB.prepareStatement(verifyLogin)) {
        preparedStatement.setString(1, usernameTextField.getText().trim());
        preparedStatement.setString(2, passwordpasswordField.getText().trim());

        try (ResultSet queryResult = preparedStatement.executeQuery()) {
            if (queryResult.next()) {
                String jobPosition = queryResult.getString("jobPosition");

                // บันทึก username ลงใน UserSession
                UserSession.getInstance().setUsername(usernameTextField.getText().trim());

                Parent root;
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene;

                switch (jobPosition) {
                    case "Staff":
                        root = FXMLLoader.load(getClass().getResource("/application/saler.fxml"));
                        break;
                    case "Manager":
                        root = FXMLLoader.load(getClass().getResource("/manager/manager.fxml"));
                        break;
                    case "Admin":
                        root = FXMLLoader.load(getClass().getResource("/admin/main.fxml"));
                        break;
                    default:
                        loginMessageLabel.setText("Invalid job position.");
                        return;
                }

                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } else {
                loginMessageLabel.setText("Invalid Login. Please try again.");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}


}



