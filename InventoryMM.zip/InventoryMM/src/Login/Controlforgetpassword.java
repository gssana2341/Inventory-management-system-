
package Login;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import application.connectsql;

public class Controlforgetpassword {
	@FXML
	private Button back;

	@FXML
	private Label labelshow;

	@FXML
	private TextField nameuselogin;

	@FXML
	private TextField newpassword;

	@FXML
	private TextField oldpassword;

	@FXML
	private Button save;
	
	@FXML
    void back(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Login/login.fxml"));
	    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow(); 
	    Scene scene = new Scene(root);
	    stage.setScene(scene);
	    stage.show();
    }
	@FXML
	private void initialize() {
		save.setOnAction(event -> resetPassword());
	}

	private void resetPassword() {
		String username = nameuselogin.getText();
		String oldPass = oldpassword.getText();
		String newPass = newpassword.getText();

		if (username.isEmpty() || oldPass.isEmpty() || newPass.isEmpty()) {
			labelshow.setText("Please fill in all fields.");
			labelshow.setStyle("-fx-text-fill: red;");
			return;
		}

		boolean usernameExists = checkUsername(username);
		boolean oldPasswordValid = checkOldPassword(username, oldPass);

		if (usernameExists && oldPasswordValid) {
			labelshow.setText("Please change your password within your profile.");
			labelshow.setStyle("-fx-text-fill: red;");
		} else if (usernameExists) {
			updatePassword(username, newPass);
			labelshow.setText("Password updated successfully.");
			labelshow.setStyle("-fx-text-fill: green;");
			clearFields();
		} else if (oldPasswordValid) {
			labelshow.setText("You remember your password.");
			labelshow.setStyle("-fx-text-fill: red;");
		} else {
			labelshow.setText("Username not found.");
			labelshow.setStyle("-fx-text-fill: red;");
		}
	}

	private boolean checkUsername(String username) {
		boolean exists = false;
		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT username FROM user WHERE username = ?")) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			exists = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return exists;
	}

	private boolean checkOldPassword(String username, String oldPass) {
		boolean isValid = false;
		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT password FROM user WHERE username = ?")) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				String storedPassword = rs.getString("password");
				isValid = storedPassword.equals(oldPass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isValid;
	}

	private void updatePassword(String username, String newPass) {
		try (Connection conn = new connectsql().getConnection();
				PreparedStatement stmt = conn.prepareStatement("UPDATE user SET password = ? WHERE username = ?")) {
			stmt.setString(1, newPass);
			stmt.setString(2, username);
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void clearFields() {
		nameuselogin.clear();
		oldpassword.clear();
		newpassword.clear();
	}
}
